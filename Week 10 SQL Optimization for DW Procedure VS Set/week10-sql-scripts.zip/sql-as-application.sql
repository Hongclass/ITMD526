  WITh sales_trans AS
       (
        SELECT '201501' AS yyyymm, 10000 AS amt FROM dual UNION ALL
        SELECT '201502' AS yyyymm, 20000 AS amt FROM dual UNION ALL
        SELECT '201503' AS yyyymm, 15000 AS amt FROM dual
       ),
       production_cost AS
       (
        SELECT '201501' AS yyyymm, 9000 AS amt FROM dual UNION ALL
        SELECT '201502' AS yyyymm, 18000 AS amt FROM dual UNION ALL
        SELECT '201503' AS yyyymm, 11000 AS amt FROM dual
       ),
       cost_trans AS 
       (
        SELECT '211' account_no, '20150101' AS yyyymmdd, 100 AS amt FROM dual UNION ALL
        SELECT '211' account_no, '20150201' AS yyyymmdd, 110 AS amt FROM dual UNION ALL
        SELECT '211' account_no, '20150301' AS yyyymmdd, 120 AS amt FROM dual UNION ALL

        SELECT '212' account_no, '20150101' AS yyyymmdd, 100 AS amt FROM dual UNION ALL
        SELECT '212' account_no, '20150201' AS yyyymmdd, 111 AS amt FROM dual UNION ALL
        SELECT '212' account_no, '20150301' AS yyyymmdd, 123 AS amt FROM dual UNION ALL

        SELECT '213' account_no, '20150101' AS yyyymmdd, 150 AS amt FROM dual UNION ALL
        SELECT '213' account_no, '20150201' AS yyyymmdd, 130 AS amt FROM dual UNION ALL
        SELECT '213' account_no, '20150301' AS yyyymmdd, 143 AS amt FROM dual UNION ALL

        SELECT '214' account_no, '20150101' AS yyyymmdd, 163 AS amt FROM dual UNION ALL
        SELECT '214' account_no, '20150201' AS yyyymmdd, 121 AS amt FROM dual UNION ALL
        SELECT '214' account_no, '20150301' AS yyyymmdd, 197 AS amt FROM dual UNION ALL

        SELECT '215' account_no, '20150101' AS yyyymmdd, 110 AS amt FROM dual UNION ALL
        SELECT '215' account_no, '20150201' AS yyyymmdd, 156 AS amt FROM dual UNION ALL
        SELECT '215' account_no, '20150301' AS yyyymmdd, 150 AS amt FROM dual UNION ALL

        SELECT '221' account_no, '20150101' AS yyyymmdd, 176 AS amt FROM dual UNION ALL
        SELECT '221' account_no, '20150201' AS yyyymmdd, 186 AS amt FROM dual UNION ALL
        SELECT '221' account_no, '20150301' AS yyyymmdd, 122 AS amt FROM dual UNION ALL

        SELECT '222' account_no, '20150101' AS yyyymmdd, 111 AS amt FROM dual UNION ALL
        SELECT '222' account_no, '20150201' AS yyyymmdd, 135 AS amt FROM dual UNION ALL
        SELECT '222' account_no, '20150301' AS yyyymmdd, 134 AS amt FROM dual UNION ALL

        SELECT '224' account_no, '20150101' AS yyyymmdd, 211 AS amt FROM dual UNION ALL
        SELECT '224' account_no, '20150201' AS yyyymmdd, 135 AS amt FROM dual UNION ALL
        SELECT '224' account_no, '20150301' AS yyyymmdd, 334 AS amt FROM dual UNION ALL

        SELECT '229' account_no, '20150101' AS yyyymmdd, 111 AS amt FROM dual UNION ALL
        SELECT '229' account_no, '20150201' AS yyyymmdd, 135 AS amt FROM dual UNION ALL
        SELECT '229' account_no, '20150301' AS yyyymmdd, 134 AS amt FROM dual
       ),
       clone_t AS
       (
        SELECT rownum no, TRIM(TO_CHAR(rownum,'00')) day_of_month
          FROM dual
        CONNECT BY level <= 31       
       )       
SELECT no AS LINE, 
       sum(tot*decode(NO-LINE,1,-1,3,-1,1) ) TOTAL,
       sum(m01*decode(NO-LINE,1,-1,3,-1,1)) AS JAN,  sum(m02*decode(NO-LINE,1,-1,3,-1,1)) AS FEB, sum(m03*decode(NO-LINE,1,-1,3,-1,1)) AS MAR
  FROM (
        SELECT LINE, sum(AMT) TOT,
               sum(decode(MM,'01',AMT)) m01,  sum(decode(MM,'02',AMT)) m02, sum(decode(MM,'03',AMT)) m03
          FROM (
                SELECT y.NO LINE, MM, sum(AMT*decode(y.NO*LINE,6,-1,1) ) AMT
                  FROM (SELECT '1'  LINE,  substr(yyyymm,5,2) MM, sum(AMT) AMT  
                          FROM sales_trans
                         WHERE yyyymm LIKE '2015%'
                         GROUP BY substr(yyyymm,5,2)
                         UNION ALL
                        SELECT '2' LINE, substr(yyyymm,5,2) MM, sum(AMT) AMT
                          FROM production_cost
                         WHERE yyyymm LIKE '2015%'
                         GROUP BY substr(yyyymm,5,2) 
                       ) x, clone_t y
                 WHERE y.NO IN (LINE, 3)
                   AND y.no <=14
                 GROUP BY y.NO, MM
                 UNION ALL
                SELECT y.NO LINE, MM, SUM(AMT*decode(y.NO*LINE,88,-1,1) ) AMT
                  FROM (SELECT DECODE(SUBSTR(account_no,1,3),'211',4, '212',5, '213',6, '214',7, '215',8, '221',9, '222',10, 13) LINE, substr(yyyymmdd,5,2) MM, SUM(AMT) AMT
                          FROM cost_trans
                         WHERE yyyymmdd LIKE '2015%'
                           AND account_no BETWEEN '211' AND '229'
                         GROUP BY decode(substr(account_no,1,3),'211',4, '212',5, '213',6, '214',7, '215',8, '221',9, '222',10, 13), substr(yyyymmdd,5,2)
                       ) x, clone_t y
                 WHERE y.NO IN (LINE, decode(LINE,13,NULL,11))
                   AND y.no <=14
                 GROUP BY y.NO, MM 
             )
        GROUP BY LINE 
       ) x,  clone_t  y
 WHERE y.NO IN (LINE, decode(LINE,3,12, 11,12), decode(LINE,3,14,11,14,13,14))
   AND y.no <=14
 GROUP BY y.NO  
 ORDER BY y.NO;       
/*       
SELECT DECODE(SUBSTR(account_no,1,3),'211',4, '212',5, '213',6, '214',7, '215',8, '221',9, '222',10, 13) LINE, SUBSTR(yyyymmdd,5,2) MM, SUM(AMT) AMT
  FROM cost_trans
 WHERE yyyymmdd LIKE '2015%'
   AND account_no BETWEEN '211' AND '229'
 GROUP BY DECODE(SUBSTR(account_no,1,3),'211',4, '212',5, '213',6, '214',7, '215',8, '221',9, '222',10, 13), SUBSTR(yyyymmdd,5,2)

SELECT '1'  LINE, SUBSTR(yyyymm,5,2) MM, SUM(AMT) AMT
  FROM sales_trans
 WHERE yyyymm LIKE '2015%'
 GROUP BY SUBSTR(yyyymm,5,2)

SELECT '2'  LINE, SUBSTR(yyyymm,5,2) MM, SUM(AMT) AMT
  FROM production_cost
 WHERE yyyymm LIKE '2015%'
 GROUP BY SUBSTR(yyyymm,5,2)
; 
*/