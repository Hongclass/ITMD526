-- lost, 'suspended for late payment', 'senior', 'suspended by user'
-- reduction of fractions to a common denominatorreduction of fractions to a common denominator

  WITH cust_status AS 
       (
        SELECT  1 AS cust_status_id, 'c001' cust_id, 'suspend-user' reason, '20150104' start_dt, '20150218' end_dt FROM dual UNION ALL
        SELECT  2 AS cust_status_id, 'c001' cust_id, 'suspend-user' reason, '20150215' start_dt, '20150302' end_dt FROM dual UNION ALL
        SELECT  3 AS cust_status_id, 'c001' cust_id, 'lost' reason, '20150304' start_dt, '20150310' end_dt FROM dual UNION ALL
        SELECT  4 AS cust_status_id, 'c001' cust_id, 'suspend-payment' reason, '20150317' start_dt, '20150327' end_dt FROM dual UNION ALL
        SELECT  5 AS cust_status_id, 'c001' cust_id, 'senior' reason, '20150325' start_dt, '20990101' end_dt FROM dual  UNION ALL
        SELECT  6 AS cust_status_id, 'c001' cust_id, 'suspend-user' reason, '20150404' start_dt, '20150419' end_dt FROM dual
        UNION ALL
        SELECT  7 AS cust_status_id, 'c002' cust_id, 'suspend-user' reason, '20150108' start_dt, '20150218' end_dt FROM dual UNION ALL
        SELECT  8 AS cust_status_id, 'c002' cust_id, 'suspend-user' reason, '20150215' start_dt, '20150304' end_dt FROM dual UNION ALL
        SELECT  9 AS cust_status_id, 'c002' cust_id, 'lost' reason, '20150308' start_dt, '20150310' end_dt FROM dual UNION ALL
        SELECT 10 AS cust_status_id, 'c002' cust_id, 'suspend-payment' reason, '20150317' start_dt, '20150327' end_dt FROM dual UNION ALL
        SELECT 11 AS cust_status_id, 'c002' cust_id, 'senior' reason, '20150325' start_dt, '20990101' end_dt FROM dual  UNION ALL
        SELECT 12 AS cust_status_id, 'c002' cust_id, 'suspend-user' reason, '20150404' start_dt, '20150419' end_dt FROM dual        
        UNION ALL
        SELECT 13 AS cust_status_id, 'c003' cust_id, 'suspend-user' reason, '20150315' start_dt, '20150315' end_dt FROM dual        

       ),
       clone_t AS
       (
        SELECT rownum no, TRIM(TO_CHAR(rownum,'00')) day_of_month
          FROM dual
        CONNECT BY level <= 31       
       )
SELECT e.cust_id, COUNT(*) AS discount_days, SUM(e.discount_amt) AS discount_amt, 2*31-SUM(e.discount_amt) AS billing_amt
  FROM (
        SELECT d.cust_id, d.day_of_month, 
               MAX(reduced_rate1) AS reduced_rate1, 
               MAX(reduced_rate2) AS reduced_rate2, 
               NVL(MAX(reduced_rate1),1)*NVL(MAX(reduced_rate2),1) AS reduced_rate_final, 
               2*(NVL(MAX(reduced_rate1),1)*NVL(MAX(reduced_rate2),1)) AS discount_amt -- original rate: $2/day
          FROM (
                SELECT c.cust_status_id, c.cust_id, c.reason, c.start_dt, c.end_dt, t.day_of_month,
                       DECODE(c.reason, 'suspend-user', 0.9, 'lost', 0.9, 'suspend-payment', 0.9) AS reduced_rate1,
                       DECODE(c.reason, 'senior', 0.2) AS reduced_rate2
                       -- , SUBSTR(c.start_dt, 7,2) AS start_day_of_month, SUBSTR(c.end_dt, 7,2) AS end_day_of_month
                  FROM (
                        SELECT cust_status_id, cust_id, reason, GREATEST(start_dt, '20150301') AS start_dt, LEAST(end_dt, '20150331') AS end_dt
                          FROM cust_status
                         WHERE 1=1
                --           AND cust_status_id IN (2,3)
                           AND start_dt <= '20150331'
                           AND end_dt >= '20150301'
                       ) c, clone_t t
                 WHERE 1=1
                   AND t.day_of_month BETWEEN SUBSTR(c.start_dt, 7,2) AND SUBSTR(c.end_dt, 7,2)
                 ORDER BY t.day_of_month
               ) d
         GROUP BY d.cust_id, d.day_of_month
         ORDER BY d.cust_id, d.day_of_month
       ) e
 GROUP BY e.cust_id
;


-- Simpler version

SELECT b.cust_id, b.day_of_month, MAX(b.reduced_rate1), MAX(b.reduced_rate2)
  FROM (
        SELECT c.*, clone_t.day_of_month
        --       , SUBSTR(a.start_dt, 7,2) AS sday, SUBSTR(a.end_dt, 7,2) AS eday, clone_t.day_of_month
               , DECODE(c.reason, 'suspend-user', 0.9, 'lost', 0.9, 'suspend-payment', 0.9) AS reduced_rate1
               , DECODE(c.reason, 'senior', 0.2) AS reduced_rate2
          FROM (
                SELECT cust_status_id, cust_id, reason, GREATEST(start_dt, '20150301') AS start_dt, LEAST(end_dt, '20150331') AS end_dt
                  FROM
                      (
                        SELECT  1 AS cust_status_id, 'c001' cust_id, 'suspend-user' reason, '20150304' start_dt, '20150308' end_dt FROM dual  UNION ALL
                        SELECT  2 AS cust_status_id, 'c001' cust_id, 'senior' reason, '20150306' start_dt, '20990101' end_dt FROM dual  
                      )
               ) c,
               (
                SELECT rownum AS no, TRIM(TO_CHAR(rownum, '00')) day_of_month
                  FROM dual
               CONNECT BY level <= 31
               ) clone_t
         WHERE clone_t.day_of_month BETWEEN SUBSTR(c.start_dt, 7,2) AND SUBSTR(c.end_dt, 7,2)
       ) b
 GROUP BY  b.cust_id, b.day_of_month
 ORDER BY 1, day_of_month
;