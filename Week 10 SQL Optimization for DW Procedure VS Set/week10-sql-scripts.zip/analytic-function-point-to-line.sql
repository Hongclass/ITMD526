   WITH tab_a AS 
       (
        SELECT 1 AS id, 'e1' empid, 'a' jobcode, 20110101 start_dt, 3000 sal FROM dual UNION ALL
        SELECT 2 AS id, 'e1' empid, 'a' jobcode, 20120202 start_dt, 3200 sal FROM dual UNION ALL
        SELECT 3 AS id, 'e1' empid, 'b' jobcode, 20130303 start_dt, 3300 sal FROM dual UNION ALL
        SELECT 4 AS id, 'e1' empid, 'b' jobcode, 20140404 start_dt, 4100 sal  FROM dual --UNION ALL  
--        SELECT 5 AS id, 'e2' empid, 'a' jobcode, 20101010 start_dt, 1200 sal  FROM dual UNION ALL
--        SELECT 6 AS id, 'e2' empid, 'a' jobcode, 20111111 start_dt, 2000 sal  FROM dual
       )
SELECT id, empid, jobcode, start_dt, sal
       , LAG(start_dt, 1) OVER (PARTITION BY empid ORDER BY id)  AS prev_jobcode
       , LEAD(start_dt, 1) OVER (PARTITION BY empid ORDER BY id) AS next_jobcode
       , SUM(sal) OVER (PARTITION BY empid ORDER BY id) AS sal_running_total
  FROM tab_a
;


  WITH job_status_trans AS
       (
        SELECT '1234567' AS EMPLID,'331600' AS DEPTID,'BIT' AS PAYGROUP,'A' EMPL_STATUS,
                       ' ' AS POSITION_NBR,'100029' JOBCODE,to_date('21-APR-2003','DD-MON-RRRR') EFFDT, 0 EFFSEQ FROM DUAL UNION ALL
        SELECT '1234567','331600','BIR','A','00036477','102590',to_date('02-DEC-2003','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','BIR','A','00036477','102590',to_date('29-AUG-2004','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','BIR','A','00036477','102590',to_date('01-SEP-2004','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','BIR','A','00036477','100278',to_date('01-DEC-2004','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','100278',to_date('01-DEC-2004','DD-MON-RRRR'),1 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','100278',to_date('01-SEP-2005','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','100278',to_date('23-SEP-2005','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','100294',to_date('01-JAN-2006','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','100294',to_date('01-JAN-2006','DD-MON-RRRR'),1 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104369',to_date('01-JUN-2006','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104369',to_date('01-JUL-2006','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104369',to_date('01-SEP-2006','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104369',to_date('01-OCT-2006','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104369',to_date('01-SEP-2007','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104369',to_date('01-JAN-2008','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-MAR-2008','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-MAR-2008','DD-MON-RRRR'),1 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-SEP-2008','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-JAN-2009','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-APR-2009','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-JUN-2009','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('27-JUL-2009','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-SEP-2009','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-JAN-2010','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-SEP-2010','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-JAN-2011','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-SEP-2011','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-FEB-2012','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-SEP-2012','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-JAN-2013','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','331600','MON','A','00036477','104342',to_date('01-SEP-2013','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','791200','MON','A','00055668','213000',to_date('06-JAN-2014','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','791200','MON','A','00055668','213000',to_date('01-JUN-2014','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','791200','MON','A','00055668','213000',to_date('01-SEP-2014','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','791200','MON','T','00055668','213000',to_date('20-JUL-2015','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','791200','MON','A','00055668','213000',to_date('14-AUG-2015','DD-MON-RRRR'),0 FROM DUAL UNION ALL
        SELECT '1234567','791200','MON','A','00055668','213000',to_date('08-SEP-2015','DD-MON-RRRR'),0 FROM DUAL 
       )
-- Adding PAYGROUP
SELECT emplid, position_nbr, paygroup, MAX(pos_xfr_to) AS pos_xfr_to, MIN(effdt_from) AS effdt_from, MAX(effdt_to) AS effdt_to
  FROM (
        SELECT emplid, position_nbr, paygroup, DECODE(next_position_nbr, position_nbr, ' ', next_position_nbr) AS pos_xfr_to, effdt_from, effdt_to
               , SUM(flg_position_change) OVER (PARTITION BY emplid ORDER BY seq) AS pos_group_id
               , SUM(flg_terminate) OVER (PARTITION BY emplid ORDER BY seq) AS ter_group_id
               , SUM(flg_paygroup_change) OVER (PARTITION BY emplid ORDER BY seq) AS paygroup_group_id
          FROM (
                SELECT emplid
                       , position_nbr, LEAD(position_nbr,1) OVER (PARTITION BY emplid ORDER BY effdt, effseq) AS next_position_nbr
                       , paygroup--, LEAD(paygroup,1) OVER (PARTITION BY emplid ORDER BY effdt, effseq) AS next_paygroup 
                       , empl_status, effdt AS effdt_from
                       , NVL(LEAD(effdt, 1) OVER (PARTITION BY emplid ORDER BY effdt, effseq), TO_DATE('29990102', 'YYYYMMDD'))-1 AS effdt_to
                       , ROW_NUMBER() OVER (PARTITION BY emplid ORDER BY effdt, effseq) AS seq
                       , NVL(LAG(position_nbr, 1) OVER (PARTITION BY emplid ORDER BY effdt, effseq), 'N/A') AS prev_position_nbr
                       , CASE WHEN position_nbr != NVL(LAG(position_nbr, 1) OVER (PARTITION BY emplid ORDER BY effdt, effseq), 'N/A') THEN 1 ELSE 0 END AS flg_position_change
                       , CASE NVL(LAG(empl_status, 1) OVER (PARTITION BY emplid ORDER BY effdt, effseq),'N/A') WHEN 'T' THEN 1 ELSE 0 END AS flg_terminate
                       , CASE WHEN paygroup != NVL(LAG(paygroup, 1) OVER (PARTITION BY emplid ORDER BY effdt, effseq), 'N/A') THEN 1 ELSE 0 END AS flg_paygroup_change
                  FROM job_status_trans
               ) a
         WHERE 1=1
           AND empl_status != 'T'
       ) b  
 GROUP BY emplid, position_nbr, paygroup, pos_group_id, ter_group_id, paygroup_group_id
 ORDER BY 2
;
 
EMPLID  POSITION_NBR PAYGROUP POS_XFR_TO EFFDT_FROM  EFFDT_TO  
------- ------------ -------- ---------- ----------- -----------
1234567              BIT      00036477   21-APR-2003 01-DEC-2003 
1234567 00036477     BIR                 02-DEC-2003 30-NOV-2004 
1234567 00036477     MON      00055668   01-DEC-2004 05-JAN-2014 
1234567 00055668     MON                 06-JAN-2014 19-JUL-2015 
1234567 00055668     MON                 14-AUG-2015 01-JAN-2999 
































;
